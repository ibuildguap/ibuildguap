var fgImage = null;

function loadForegroundImage() {
  var file = document.getElementById("fgfile");
  fgImage = new SimpleImage(file);
  fgCanvas = document.getElementById("fgcan");
  fgImage.drawTo(fgCanvas);
}



function doGreenScreen() {

  if (fgImage == null  || ! fgImage.complete()) {
    alert("uh oh, image not loaded");
  }
}

var drawnImage; {

function drawImage(ev)
{
  console.log(ev);
  var context = document.getElementById("canvas")
  .getContext ("2d")
img = newImage();
  files = document.getElementById("uploadimage").files
}
}
 
  
function clearcanvas() {
context.clearfgImage(250, 500, canvas.width, canvas.height);
  evaluate (canvas.value);
  drawImage();
}


function addBlur() {
 fgcan.addEventListener
  ("click",blur)
console.log('blur');
  fgcan.style.filter = "blur(10px)" 
}
